// Configuration settings for the Quick Notes extension
const CONFIG = {
  // The URL of your notes API
  // Change this to your actual API URL when deploying
  API_URL: "http://localhost:3000/api/notes",
};
